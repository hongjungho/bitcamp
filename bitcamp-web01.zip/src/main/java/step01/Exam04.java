// 서블릿 만들기 4 - HTTP 프로토콜 다루느느 기능이 추가된 HttpServlet 상속 받아 만들기
package step01;

import javax.servlet.annotation.WebServlet;

// => 비록 HttpSrvlet 클래슨느 추상메서드가 없지만
//    이 클래스의 목적이 서브클래스에서 공통 기능을 상속해주는 것이기 때문에
//    바로 사용할 수 없도록 추상 클래스로 선언한다.
@WebServlet("/step01/exam04")
public class Exam04 extends HttpServlet {
    
}







